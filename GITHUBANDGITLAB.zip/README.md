<p align="center">
  <a href="https://fgfobdpqjs.github.io/index.html"><img src="https://fgfobdpqjs.github.io/b62ca8ec10d07e6bf5ac8dae0c8c1d2e6a1e3356.png" width="100" height="100" alt="eee"></a>
</p>
<div align="center">

# 我的网页

_🦌 一个网页 🥛_

</div>


## 简介

代码太简单了，我不知道该怎么说

[English](README_EN.md)
|
[繁體中文](README_zh_Hant.md)
|
[YouTube](https://www.youtube.com/channel/UC-iw8JRgEAAxz6-rYdaKxWg)
|
[Tiktok](https://www.tiktok.com/@fgfobdpqjs)
|
[Reddit](https://www.reddit.com/user/Typical-Evidence9300/)
|
[GitHub](https://github.com/fgfobdpqjs)
|
[GitLab](https://gitlab.com/fgfobdpqjs)
|
[抖音中国1](https://www.douyin.com/user/MS4wLjABAAAACKPckCBA9Xnxy2YCRQY2m0xDegN-kmkzht0ohyyk5ts)
|
[抖音中国2](https://www.douyin.com/user/MS4wLjABAAAAryQaEzPsiKTuTzYs6UDjQ5yNkltUdJU5fSEr_MJtlMm8hP4fCdBoBO4zAbyHMx3p)
|
[西瓜视频](https://www.ixigua.com/home/1456218970008591/?list_entrance=search)
|
[快手中国](https://www.kuaishou.com/profile/3xk34uvfv6fkcj6)
|
[Github Pages](https://fgfobdpqjs.github.io/index.html)

## 其它事项

点下star吧~ 欢迎pr代码
